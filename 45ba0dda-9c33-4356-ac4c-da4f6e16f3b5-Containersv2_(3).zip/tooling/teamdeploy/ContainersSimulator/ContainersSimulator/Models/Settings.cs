﻿namespace ContainersSimulator.Models
{
    public class Settings
    {
        public string ResourceGroupName { get; set; }

        public string DataStorageConnectionString { get; set; }

        public string ApplicationInsightsKey { get; set; }
    }
}
